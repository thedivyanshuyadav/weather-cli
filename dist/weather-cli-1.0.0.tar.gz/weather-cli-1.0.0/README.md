Command :
```
weather [city]
``` 

Weather Information:
```
1. Humidity
2. Pressure
3. Average temperature
4. Wind Speed
5. Wind degree
6. UV Index
```